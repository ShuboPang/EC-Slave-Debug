#! /bin/sh
if [ -f ./ModbusUartProgramer ];then 
	if [ -f ./*rom.bin ];then
		chmod +x ModbusUartProgramer
		./ModbusUartProgramer /dev/ttySZHC0 rom.bin 1 -qws 
	fi
fi

tar xJvf usr.tar.xz -C /
${PWD}/UpdateGUI update_cmd -qws

sync

reboot
